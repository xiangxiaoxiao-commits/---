﻿namespace student
{
    partial class frmmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.基本表维护ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学生成绩查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学生名次查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学生信息插入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.课程ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.课程信息插入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.教师任课查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.教师信息插入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.班级课程开设查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.班级信息插入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.班级排名ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.专业信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.专业信息插入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.课程成绩排名ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.教师任课查询ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.查询所学课程及学分统计ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.按照课程排名ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学年学生成绩查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.地区人数统计ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.文件ToolStripMenuItem,
            this.基本表维护ToolStripMenuItem,
            this.课程ToolStripMenuItem,
            this.教师任课查询ToolStripMenuItem,
            this.班级课程开设查询ToolStripMenuItem,
            this.专业信息管理ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 文件ToolStripMenuItem
            // 
            this.文件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.退出ToolStripMenuItem});
            this.文件ToolStripMenuItem.Name = "文件ToolStripMenuItem";
            this.文件ToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.文件ToolStripMenuItem.Text = "文件";
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // 基本表维护ToolStripMenuItem
            // 
            this.基本表维护ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.学生成绩查询ToolStripMenuItem,
            this.学生名次查询ToolStripMenuItem,
            this.学生信息插入ToolStripMenuItem,
            this.地区人数统计ToolStripMenuItem});
            this.基本表维护ToolStripMenuItem.Name = "基本表维护ToolStripMenuItem";
            this.基本表维护ToolStripMenuItem.Size = new System.Drawing.Size(113, 24);
            this.基本表维护ToolStripMenuItem.Text = "学生信息管理";
            // 
            // 学生成绩查询ToolStripMenuItem
            // 
            this.学生成绩查询ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.查询所学课程及学分统计ToolStripMenuItem,
            this.学年学生成绩查询ToolStripMenuItem});
            this.学生成绩查询ToolStripMenuItem.Name = "学生成绩查询ToolStripMenuItem";
            this.学生成绩查询ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.学生成绩查询ToolStripMenuItem.Text = "学生成绩查询";
            // 
            // 学生名次查询ToolStripMenuItem
            // 
            this.学生名次查询ToolStripMenuItem.Name = "学生名次查询ToolStripMenuItem";
            this.学生名次查询ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.学生名次查询ToolStripMenuItem.Text = "学生成绩插入查询";
            this.学生名次查询ToolStripMenuItem.Click += new System.EventHandler(this.学生名次查询ToolStripMenuItem_Click);
            // 
            // 学生信息插入ToolStripMenuItem
            // 
            this.学生信息插入ToolStripMenuItem.Name = "学生信息插入ToolStripMenuItem";
            this.学生信息插入ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.学生信息插入ToolStripMenuItem.Text = "学生信息插入查询";
            this.学生信息插入ToolStripMenuItem.Click += new System.EventHandler(this.学生信息插入ToolStripMenuItem_Click);
            // 
            // 课程ToolStripMenuItem
            // 
            this.课程ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.课程信息插入ToolStripMenuItem,
            this.课程成绩排名ToolStripMenuItem,
            this.按照课程排名ToolStripMenuItem});
            this.课程ToolStripMenuItem.Name = "课程ToolStripMenuItem";
            this.课程ToolStripMenuItem.Size = new System.Drawing.Size(113, 24);
            this.课程ToolStripMenuItem.Text = "课程信息管理";
            // 
            // 课程信息插入ToolStripMenuItem
            // 
            this.课程信息插入ToolStripMenuItem.Name = "课程信息插入ToolStripMenuItem";
            this.课程信息插入ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.课程信息插入ToolStripMenuItem.Text = "课程信息插入查询";
            this.课程信息插入ToolStripMenuItem.Click += new System.EventHandler(this.课程信息插入ToolStripMenuItem_Click);
            // 
            // 教师任课查询ToolStripMenuItem
            // 
            this.教师任课查询ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.教师信息插入ToolStripMenuItem,
            this.教师任课查询ToolStripMenuItem1});
            this.教师任课查询ToolStripMenuItem.Name = "教师任课查询ToolStripMenuItem";
            this.教师任课查询ToolStripMenuItem.Size = new System.Drawing.Size(113, 24);
            this.教师任课查询ToolStripMenuItem.Text = "教师信息管理";
            // 
            // 教师信息插入ToolStripMenuItem
            // 
            this.教师信息插入ToolStripMenuItem.Name = "教师信息插入ToolStripMenuItem";
            this.教师信息插入ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.教师信息插入ToolStripMenuItem.Text = "教师信息插入查询";
            this.教师信息插入ToolStripMenuItem.Click += new System.EventHandler(this.教师信息插入ToolStripMenuItem_Click);
            // 
            // 班级课程开设查询ToolStripMenuItem
            // 
            this.班级课程开设查询ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.班级信息插入ToolStripMenuItem,
            this.班级排名ToolStripMenuItem});
            this.班级课程开设查询ToolStripMenuItem.Name = "班级课程开设查询ToolStripMenuItem";
            this.班级课程开设查询ToolStripMenuItem.Size = new System.Drawing.Size(113, 24);
            this.班级课程开设查询ToolStripMenuItem.Text = "班级信息管理";
            // 
            // 班级信息插入ToolStripMenuItem
            // 
            this.班级信息插入ToolStripMenuItem.Name = "班级信息插入ToolStripMenuItem";
            this.班级信息插入ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.班级信息插入ToolStripMenuItem.Text = "班级信息插入查询";
            this.班级信息插入ToolStripMenuItem.Click += new System.EventHandler(this.班级信息插入ToolStripMenuItem_Click);
            // 
            // 班级排名ToolStripMenuItem
            // 
            this.班级排名ToolStripMenuItem.Name = "班级排名ToolStripMenuItem";
            this.班级排名ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.班级排名ToolStripMenuItem.Text = "班级开设课程查询";
            this.班级排名ToolStripMenuItem.Click += new System.EventHandler(this.班级排名ToolStripMenuItem_Click);
            // 
            // 专业信息管理ToolStripMenuItem
            // 
            this.专业信息管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.专业信息插入ToolStripMenuItem});
            this.专业信息管理ToolStripMenuItem.Name = "专业信息管理ToolStripMenuItem";
            this.专业信息管理ToolStripMenuItem.Size = new System.Drawing.Size(113, 24);
            this.专业信息管理ToolStripMenuItem.Text = "专业信息管理";
            // 
            // 专业信息插入ToolStripMenuItem
            // 
            this.专业信息插入ToolStripMenuItem.Name = "专业信息插入ToolStripMenuItem";
            this.专业信息插入ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.专业信息插入ToolStripMenuItem.Text = "专业信息插入查询";
            this.专业信息插入ToolStripMenuItem.Click += new System.EventHandler(this.专业信息插入ToolStripMenuItem_Click);
            // 
            // 课程成绩排名ToolStripMenuItem
            // 
            this.课程成绩排名ToolStripMenuItem.Name = "课程成绩排名ToolStripMenuItem";
            this.课程成绩排名ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.课程成绩排名ToolStripMenuItem.Text = "课程成绩均分查询";
            this.课程成绩排名ToolStripMenuItem.Click += new System.EventHandler(this.课程成绩排名ToolStripMenuItem_Click);
            // 
            // 教师任课查询ToolStripMenuItem1
            // 
            this.教师任课查询ToolStripMenuItem1.Name = "教师任课查询ToolStripMenuItem1";
            this.教师任课查询ToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.教师任课查询ToolStripMenuItem1.Text = "教师任课查询";
            this.教师任课查询ToolStripMenuItem1.Click += new System.EventHandler(this.教师任课查询ToolStripMenuItem1_Click);
            // 
            // 查询所学课程及学分统计ToolStripMenuItem
            // 
            this.查询所学课程及学分统计ToolStripMenuItem.Name = "查询所学课程及学分统计ToolStripMenuItem";
            this.查询所学课程及学分统计ToolStripMenuItem.Size = new System.Drawing.Size(257, 26);
            this.查询所学课程及学分统计ToolStripMenuItem.Text = "查询所学课程及学分统计";
            this.查询所学课程及学分统计ToolStripMenuItem.Click += new System.EventHandler(this.查询所学课程及学分统计ToolStripMenuItem_Click);
            // 
            // 按照课程排名ToolStripMenuItem
            // 
            this.按照课程排名ToolStripMenuItem.Name = "按照课程排名ToolStripMenuItem";
            this.按照课程排名ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.按照课程排名ToolStripMenuItem.Text = "课程排名查询";
            this.按照课程排名ToolStripMenuItem.Click += new System.EventHandler(this.按照课程排名ToolStripMenuItem_Click);
            // 
            // 学年学生成绩查询ToolStripMenuItem
            // 
            this.学年学生成绩查询ToolStripMenuItem.Name = "学年学生成绩查询ToolStripMenuItem";
            this.学年学生成绩查询ToolStripMenuItem.Size = new System.Drawing.Size(257, 26);
            this.学年学生成绩查询ToolStripMenuItem.Text = "学年学生成绩查询";
            this.学年学生成绩查询ToolStripMenuItem.Click += new System.EventHandler(this.学年学生成绩查询ToolStripMenuItem_Click);
            // 
            // 地区人数统计ToolStripMenuItem
            // 
            this.地区人数统计ToolStripMenuItem.Name = "地区人数统计ToolStripMenuItem";
            this.地区人数统计ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.地区人数统计ToolStripMenuItem.Text = "地区人数统计";
            this.地区人数统计ToolStripMenuItem.Click += new System.EventHandler(this.地区人数统计ToolStripMenuItem_Click);
            // 
            // frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmmain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "学生成绩管理查询系统";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 基本表维护ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 学生成绩查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 学生名次查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 学生信息插入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 课程ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 教师任课查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 班级课程开设查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 课程信息插入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 教师信息插入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 班级信息插入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 班级排名ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 专业信息管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 专业信息插入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 课程成绩排名ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 教师任课查询ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 查询所学课程及学分统计ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 按照课程排名ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 学年学生成绩查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 地区人数统计ToolStripMenuItem;
    }
}